1.Инструменты и техники:
	1.1:Pytest
	1.2:Проводились автотесты
	2.1:Selenium WebDriver
	2.2:доступ к сайту и работа с ним
2.pytest -v --driver Chrome --driver-path </path/to>//chromedriver.exe
