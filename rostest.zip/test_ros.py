import time
from selenium import webdriver
from selenium.webdriver.common.by import By
driver = webdriver.Chrome('<path/to>/chromedriver.exe')


#Авторизация по телефону
def test_autoriz_phone(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.ID, 'username').send_keys('79173118366') #Номер телефона
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321') #Пароль
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(7)
    driver.find_element(By.ID, 'logout-btn').click()
    time.sleep(7)


def test_negautoriz_phone(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.ID, 'username').send_keys('79173118366')
    driver.find_element(By.ID, 'password').send_keys('45512')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(5)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'

def test_negautoriz_negphone(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.ID, 'username').send_keys('79174448366')
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(5)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'

#Авторизация по почте
def test_autoriz_email(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-mail"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('ucheba.novii@bk.ru') #Почта
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321') #Пароль
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(7)
    driver.find_element(By.ID, 'logout-btn').click()
    time.sleep(7)

def test_negautoriz_email(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-mail"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('ucheba.novii@bk.ru')
    driver.find_element(By.ID, 'password').send_keys('45512')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(5)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'

def test_negautoriz_negemail(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-mail"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('ucheba.noviibk.ru')
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(6)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'

#Авторизация по логину
def test_autoriz_login(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-login"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('rtkid_1721715682938') #Логин
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321') #Пароль
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(7)
    driver.find_element(By.ID, 'logout-btn').click()
    time.sleep(7)




def test_negautoriz_login(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-login"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('rtkid_1721715682938')
    driver.find_element(By.ID, 'password').send_keys('45512')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(5)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'


def test_negautoriz_neglogin(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-login"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('rtkid_1111715682938')
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(5)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'


#Авторизация по лицевому счету
def test_autoriz_lkschet(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-ls"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('<LKSCHET>') #Лицевой счет такого у меня нет
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(7)
    driver.find_element(By.ID, 'logout-btn').click()
    time.sleep(7)

def test_negautoriz_neglkschet(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-ls"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('<NEGLKSCHET>')
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'

def test_negautoriz_lkschet(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-ls"]').click()
    time.sleep(3)
    driver.find_element(By.ID, 'username').send_keys('<LKSCHET>')
    driver.find_element(By.ID, 'password').send_keys('55123321')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.XPATH, '//*[@id="form-error-message"]').text == 'Неверный логин или пароль'

#Восстановление пароля по телефону
def test_restorepassword_phone(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '*[@id="forgot_password"]').click()
    time.sleep(7)
    driver.find_element(By.ID, 'username').send_keys('79173118366')
    time.sleep(40) # Я не понял как автоматизировать капчу, а яндекс нейронка предложила сделать задержку для ручного ввода
    driver.find_element(By.ID, 'reset').click()
    time.sleep(6)
    driver.find_element(By.ID, 'sms-reset-type').click()
    driver.find_element(By.ID, 'reset-form-submit').click()
    time.sleep(40)  # Ввести код вручную
    driver.find_element(By.XPATH, '//*[@id="password-new"]').send_keys('g40423565467')
    driver.find_element(By.XPATH, '//*[@id="password-confirm"]').send_keys('g40423565467')
    driver.find_element(By.ID, 't-btn-reset-pass').click()
    driver.find_element(By.ID, 'reset-form-submit').click()
    time.sleep(7)
    driver.find_element(By.ID, 'username').send_keys('79173118366')
    driver.find_element(By.ID, 'password').send_keys('g40423565467')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(7)
    driver.find_element(By.ID, 'logout-btn').click()
    time.sleep(7)

def test_restorepassword_negphone(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '*[@id="forgot_password"]').click()
    time.sleep(7)
    driver.find_element(By.ID, 'username').send_keys('79174448366')
    driver.find_element(By.ID, 'reset').click()
    assert driver.find_element(By.ID, 'form-error-message').text == 'Неверный логин или текст с картинки'


def test_restorepassword_phone_cap(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '*[@id="forgot_password"]').click()
    time.sleep(7)
    driver.find_element(By.ID, 'username').send_keys('79173118366')
    driver.find_element(By.ID, 'captcha').send_keys(3333333)
    driver.find_element(By.ID, 'reset').click()
    assert driver.find_element(By.ID, 'form-error-message').text == 'Неверный логин или текст с картинки'

#Восстановление пароля по почте
def test_restorepassword_email(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '*[@id="forgot_password"]').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-mail"]').click()
    time.sleep(2)
    driver.find_element(By.ID, 'username').send_keys('ucheba.novii@bk.ru')
    time.sleep(40) #Я не понял как автоматизировать капчу, а яндекс нейронка предложила сделать задержку для ручного ввода
    driver.find_element(By.ID, 'reset').click()
    time.sleep(6)
    driver.find_element(By.ID, 'email-reset-type').click()
    driver.find_element(By.ID, 'reset-form-submit').click()
    time.sleep(40)  # Ввести код вручную
    driver.find_element(By.XPATH, '//*[@id="password-new"]').send_keys('b505436653')
    driver.find_element(By.XPATH, '//*[@id="password-confirm"]').send_keys('b505436653')
    driver.find_element(By.ID, 't-btn-reset-pass').click()
    time.sleep(7)
    driver.find_element(By.ID, 'username').send_keys('ucheba.novii@bk.ru')
    driver.find_element(By.ID, 'password').send_keys('b505436653')
    driver.find_element(By.ID, 'kc-login').click()
    time.sleep(10)
    driver.find_element(By.ID, 'info_submit').click()
    time.sleep(7)
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(7)
    driver.find_element(By.ID, 'logout-btn').click()
    time.sleep(7)

def test_restorepassword_negemail(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '*[@id="forgot_password"]').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-mail"]').click()
    time.sleep(2)
    driver.find_element(By.ID, 'username').send_keys('ucheba.noviibk.ru')
    driver.find_element(By.ID, 'reset').click()
    assert driver.find_element(By.ID, 'form-error-message').text == 'Неверный логин или текст с картинки'

def test_restorepassword_email_captcha(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '*[@id="forgot_password"]').click()
    time.sleep(7)
    driver.find_element(By.XPATH, '//*[@id="t-btn-tab-mail"]').click()
    time.sleep(2)
    driver.find_element(By.ID, 'username').send_keys('ucheba.novii@bk.ru')
    driver.find_element(By.ID, 'captcha').send_keys(3333333)
    driver.find_element(By.ID, 'reset').click()
    assert driver.find_element(By.ID, 'form-error-message').text == 'Неверный логин или текст с картинки'


#Регистрация почта
def test_registration(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="kc-register"]').click()
    time.sleep(7)
    driver.find_element(By.NAME, 'firstName').send_keys('Вик')
    driver.find_element(By.NAME, 'lastName').send_keys('Рим')
    driver.find_element(By.ID, 'address').send_keys('victorica.rome@mail.ru')
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'password-confirm').send_keys('IvI4455123321')
    driver.find_element(By.XPATH, '//*[@id="page-right"]/div[1]/div[1]/div[1]/form[1]/button[1]').click()
    time.sleep(40) #Ввести код вручную
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(6)
    assert driver.find_element(By.TAG_NAME, 'h1').text == 'Вход и безопасность'
    time.sleep(6)
    driver.find_element(By.XPATH, '//*[@id="logout-btn"]').click()

def test_registration_negemail(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="kc-register"]').click()
    time.sleep(7)
    driver.find_element(By.NAME, 'firstName').send_keys('Вик')
    driver.find_element(By.NAME, 'lastName').send_keys('Рим')
    driver.find_element(By.ID, 'address').send_keys('victorica.romemail.ru')
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'password-confirm').send_keys('IvI4455123321')
    driver.find_element(By.XPATH, '//*[@id="page-right"]/div[1]/div[1]/div[1]/form[1]/button[1]').click()
    assert driver.find_element(By.XPATH, '//*[@id="page-right"]/div[1]/div[1]/div[1]/form[1]/div[3]/div[1]/span[1]').text == 'Введите телефон в формате +7ХХХХХХХХХХ или +375XXXXXXXXX, или email в формате example@email.ru'


def test_registration_latinbukvi(driver):
    driver.get('https://lk.rt.ru/')
    time.sleep(8)
    driver.find_element(By.XPATH, '//*[@id="kc-register"]').click()
    time.sleep(7)
    driver.find_element(By.NAME, 'firstName').send_keys('Vic')
    driver.find_element(By.NAME, 'lastName').send_keys('Рим')
    driver.find_element(By.ID, 'address').send_keys('victorica.rome@mail.ru')
    driver.find_element(By.ID, 'password').send_keys('IvI4455123321')
    driver.find_element(By.ID, 'password-confirm').send_keys('IvI4455123321')
    driver.find_element(By.XPATH, '//*[@id="page-right"]/div[1]/div[1]/div[1]/form[1]/button[1]').click()
    assert driver.find_element(By.XPATH, '//*[@id="page-right"]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/span[1]').text == "Необходимо заполнить поле кириллицей. От 2 до 30 символов"


driver.quit()
